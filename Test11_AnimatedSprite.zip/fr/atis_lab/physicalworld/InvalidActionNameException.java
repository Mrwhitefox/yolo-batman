package fr.atis_lab.physicalworld;

/**
 * Exception raised if an action name is erroneous
 */
public class InvalidActionNameException extends Exception {

	/**
	 * Raise an InvalidActionNameException with a personalised message
	 */
	public InvalidActionNameException(String message) {
		super(message);
	}

}
